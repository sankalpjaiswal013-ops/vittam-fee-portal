import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteNav } from "@/components/vittam/SiteNav";
import { ReceiptCard } from "@/components/vittam/ReceiptCard";
import { HeroSlabs } from "@/components/vittam/HeroSlabs";
import { inr } from "@/lib/vittam-mock";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Vittam — every rupee, reconciled" },
      { name: "description", content: "Bilingual school fee platform bridging UPI, cash, and cheque with a full reconciliation audit trail." },
      { property: "og:title", content: "Vittam — every rupee, reconciled" },
      { property: "og:description", content: "Bilingual school fee platform bridging UPI, cash, and cheque." },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen">
      <SiteNav />
      <main>
        <section className="mx-auto max-w-6xl px-6 pt-16 pb-24 sm:pt-24">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div>
              <p className="mb-4 font-mono text-xs uppercase tracking-widest text-[color:var(--marigold)]">
                School fee reconciliation
              </p>
              <h1 className="font-serif text-5xl font-semibold leading-[1.05] sm:text-6xl">
                Every rupee,<br />reconciled.
              </h1>
              <p className="mt-6 max-w-md text-lg text-muted-foreground">
                Vittam bridges UPI checkouts and offline cash or cheque deposits into one audit
                trail. Parents pay how they can. Schools see the whole ledger.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link
                  to="/student-login"
                  className="rounded-md bg-[color:var(--marigold)] px-5 py-3 text-sm font-medium text-[color:var(--primary-foreground)] shadow-sm hover:brightness-95"
                >
                  Parent login
                </Link>
                <Link
                  to="/dashboard"
                  className="rounded-md border border-border px-5 py-3 text-sm font-medium hover:bg-secondary"
                >
                  Admin console
                </Link>
              </div>
            </div>
            <HeroSlabs />
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-6 pb-24">
          <div className="grid gap-6 sm:grid-cols-3">
            <ReceiptCard>
              <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Reconciled this term</p>
              <p className="mt-3 font-serif text-4xl font-semibold text-[color:var(--banyan)]">{inr(4820000)}</p>
              <p className="mt-1 text-sm text-muted-foreground">Across 612 students</p>
            </ReceiptCard>
            <ReceiptCard>
              <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Overdue</p>
              <p className="mt-3 font-serif text-4xl font-semibold text-[color:var(--alert)]">{inr(318200)}</p>
              <p className="mt-1 text-sm text-muted-foreground">47 accounts past 7 days</p>
            </ReceiptCard>
            <ReceiptCard>
              <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Slips pending verify</p>
              <p className="mt-3 font-serif text-4xl font-semibold text-[color:var(--marigold)]">23</p>
              <p className="mt-1 text-sm text-muted-foreground">Awaiting accountant review</p>
            </ReceiptCard>
          </div>
        </section>
      </main>
      <footer className="border-t border-border/60">
        <div className="mx-auto max-w-6xl px-6 py-8 text-sm text-muted-foreground">
          © 2026 Vittam. Built for the Smart School FinTech Innovation Challenge.
        </div>
      </footer>
    </div>
  );
}
