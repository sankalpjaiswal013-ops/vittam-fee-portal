import { Link } from "@tanstack/react-router";

export function SiteNav() {
  return (
    <header className="border-b border-border/60 backdrop-blur-md bg-background/70 sticky top-0 z-40">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link to="/" className="flex items-center gap-2">
          <span className="inline-block h-6 w-6 rounded-sm bg-[color:var(--marigold)]" />
          <span className="font-serif text-xl font-semibold">Vittam</span>
        </Link>
        <nav className="hidden gap-6 text-sm text-muted-foreground sm:flex">
          <Link to="/student-login" className="hover:text-foreground">Parent login</Link>
          <Link to="/admin/students" className="hover:text-foreground">Ingest</Link>
          <Link to="/admin/verify" className="hover:text-foreground">Verify</Link>
          <Link to="/dashboard" className="hover:text-foreground">Defaulters</Link>
        </nav>
      </div>
    </header>
  );
}
